import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import {Router} from '@angular/router';
import { User } from '../user';
import {FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {

  pageTitle: string = "Create a new account today"
  pageDescription: string ="It's free and always will be!"
  successMessage:string
  errorMessage:string
  email = new FormControl('', [Validators.required, Validators.email]);
  // password = new FormControl('',[Validators.required])
  constructor(private router:Router,private userService : UserService) { }

  ngOnInit() {
  }
  // getPasswordMessage(){
  //   return this.password.hasError('required')?'Enter Password':''
  // }
  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
        this.email.hasError('email') ? 'Not a valid email' :
            '';
  }
  onSubmit(user:User){
    this.userService.registerUser(user).subscribe(
      message=>{
        this.successMessage=message
      },
      message=>{
        this.errorMessage=message
      }
    )
    this.router.navigate(['/login'])
  }
}