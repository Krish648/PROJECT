import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';
import { LoginUserComponent } from './login-user/login-user.component'
import {HttpClientModule} from'@angular/common/http';
import { UserWallComponent } from './user-wall/user-wall.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { GlobalsService } from './globals.service';
import {MatButtonModule, MatCheckboxModule, MatFormFieldModule,MatInputModule, MatError, MatFormFieldControl, MatDatepickerModule, MatNativeDateModule, MatRadioModule} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ProfileComponent } from './profile/profile.component';
import { EditProfileComponent } from './profile/EditProfile/edit-profile.component'
@NgModule({
  declarations: [
    AppComponent,
    RegisterUserComponent,
    LoginUserComponent,
    UserWallComponent,
    WelcomeComponent,
    ProfileComponent,
    EditProfileComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      {path: 'wall', component:UserWallComponent},
      {path:'welcome', component:WelcomeComponent},
      {path:'login', component:LoginUserComponent}
    ]),
    MatFormFieldModule,
    MatInputModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    BrowserAnimationsModule,
    MatRadioModule
  ],
  providers: [
    GlobalsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }