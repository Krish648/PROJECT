import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import {ActivatedRoute,Router} from '@angular/router';
import { User } from '../user';
import { GlobalsService } from '../globals.service';
import {FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})
export class LoginUserComponent implements OnInit {

  pageTitle1:string="Already a user?"
  pageTitle2:string="Sign in here"
  errorMessage:string
  public user:User
  email = new FormControl('', [Validators.required, Validators.email]);
  // password = new FormControl('',[Validators.required])
  constructor(private router:Router,private userService : UserService,private global:GlobalsService) { }

  ngOnInit() {
  }

  // getPasswordMessage(){
  //   return this.password.hasError('required')?'Enter Password':''
  // }

  getErrorMessage() {
    return this.email.hasError('required') ? 'You must enter a value' :
        this.email.hasError('email') ? 'Not a valid email' :
            '';
  }


  onClick(emailId:string,password:string){
    this.userService.loginUser(emailId, password).subscribe(
      ()=>{},
      message=>{
        this.errorMessage=message
      }
    )
    this.router.navigate(['/wall',emailId])
    
  }
}