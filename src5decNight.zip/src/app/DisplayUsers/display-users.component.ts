import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-users',
  templateUrl: './display-users.component.html',
  styleUrls: ['./display-users.component.css']
})
export class DisplayUsersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
