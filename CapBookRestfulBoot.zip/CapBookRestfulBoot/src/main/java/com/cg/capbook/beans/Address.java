package com.cg.capbook.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Address {
	private String city;
	private String state;
	private String country;
	
	
}
