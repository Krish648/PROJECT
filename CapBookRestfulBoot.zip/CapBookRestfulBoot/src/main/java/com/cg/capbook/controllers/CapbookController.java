package com.cg.capbook.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capbook.beans.User;
import com.cg.capbook.exceptions.UserDetailsNotFoundException;
import com.cg.capbook.services.UserServices;

@RestController
@CrossOrigin()
public class CapbookController {
	@Autowired 
	private UserServices userServices;
	@RequestMapping("/")
	public ModelAndView registerUserAction(@Valid @ModelAttribute User user, BindingResult result ) {
		return new ModelAndView("", "user",userServices.registerUser(user));
	}
	
	@RequestMapping("/")
	public ModelAndView getUserAction(@RequestParam("userId") int userId ) throws UserDetailsNotFoundException {
		
		return new ModelAndView("", "user",userServices.getUserDetails(userId));
	}
	@RequestMapping("/")
	public ModelAndView editUserAction(@Valid @ModelAttribute User user, BindingResult result ) {
		return new ModelAndView("", "user",userServices.editUserDetails(user));
	}
	@RequestMapping("/")
	public ModelAndView deleteUserAction(@RequestParam("userId") int userId ) throws UserDetailsNotFoundException {
		userServices.deleteUserAccount(userId);
		return new ModelAndView("","successMessage","user details have been deleted");
	}
	
}
 