package com.cg.capbook.daoservices;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.capbook.beans.User;

public interface UserDAO extends JpaRepository<User, Integer>{

	
	@Transactional
	@Modifying
	@Query("DELETE FROM User a WHERE a.userId=userId")
	public boolean deleteUserById(@Param("userId")int userId);
	
}
